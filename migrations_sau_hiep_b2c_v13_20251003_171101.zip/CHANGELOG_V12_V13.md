# CHANGELOG (V12–V13)

## V12__einvoice_minimum_compliance.sql
- Thêm bảng `einvoice_settings` (MST, tên pháp lý, chế độ ký).
- Bổ sung các cột cho `orders` (is_einvoice, buyer_*, payment_ref).
- Thêm `einvoices` (invoice_code, invoice_type, issue_date, subtotal, tax_total, grand_total, tax_authority_code, qr_text, signed_xml, status, timestamps).
- Sequence + function `make_invoice_code('SHI')`.
- View `v_invoice_print`.

## V13__vat_rate_per_product_and_sugar_halfkg.sql
- `products.vat_rate` (%), mặc định 10.
- Snapshot VAT theo dòng: `order_items.vat_rate`, `order_items.vat_amount`.
- Hàm `recompute_einvoice_totals(einvoice_id)` tính lại subtotal/tax_total.
- Seed quy cách `Đường trắng 0.5kg` (nếu đã có sản phẩm Đường trắng).
