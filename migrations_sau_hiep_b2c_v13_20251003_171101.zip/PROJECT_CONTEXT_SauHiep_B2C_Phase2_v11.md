
# 🧭 Project Context — E‑commerce vật tư nông nghiệp (B2C) — **Đại lý vật tư nông nghiệp Sáu Hiệp**  
**Phiên bản**: Phase 2 (V1…V11) • **DB**: PostgreSQL + Flyway • **Chế độ**: B2C thuần • **Không PO** • **Có Goods Receipt** • **RBAC có vai trò “staff”**

---

## 0) Mục tiêu & Phạm vi
- B2C thuần (khách lẻ), **không quản lý đại lý/agent**.
- **Không dùng Purchase Order (PO)**: nhập kho bằng **Phiếu nhập**; công nợ NCC từ **Hóa đơn NCC**.
- Tồn kho dùng **sổ chuyển động** (`inventory_movements`) + trigger đồng bộ `product_units.stock`.
- Công nợ KH (AR) hỗ trợ **trả nhiều lần + phân bổ**; Công nợ NCC (AP) tương tự.
- In ấn: view header/lines cho **Hóa đơn bán lẻ**, **Phiếu xuất kho**, **Phiếu nhập kho** đọc từ `store_settings`.
- i18n: nhãn tiếng Việt cho enum/status (bảng `*_l10n`), có thể thêm translations cho tên/mô tả.
- **RBAC**: thêm **role `staff` (nhân viên)** với quyền hạn giới hạn so với `admin`.

---

## 1) Kiến trúc dữ liệu (tóm tắt)
> Chi tiết DDL nằm trong Flyway migrations **V1 → V11**.

### 1.1 Tài khoản & Quyền hạn
- `profiles`: tài khoản người dùng (hợp nhất user/profile). `role ∈ {customer, supplier, staff, admin}`.
- `permissions`: danh mục quyền (ví dụ: `ORDERS_WRITE`, `AP_READ`, …).
- `role_permissions`: gán quyền theo **role** (admin: tất cả; staff: một phần).
- `warehouse_assignments` (tùy chọn): giới hạn **nhân viên** theo kho được thao tác.
- View `profile_effective_permissions`: quyền hiệu lực theo từng user.

### 1.2 Danh mục sản phẩm
- `categories`, `brands`, `products`, `product_units` (giữ cột `stock` để đọc nhanh).
- `price` là giá bán lẻ gợi ý; tồn cập nhật qua trigger từ `inventory_movements`.

### 1.3 Bán hàng (Sales & AR)
- `orders`, `order_items`.
- AR: `customer_payments`, `customer_payment_allocations`, `customer_adjustments`.

### 1.4 Nhập hàng & công nợ NCC (AP)
- `warehouses`.
- **Nhập kho**: `goods_receipts`, `goods_receipt_items` → trigger sinh movement **`purchase`**.
- **Nợ NCC**: `supplier_bills`, `supplier_bill_items` (dòng phí/dịch vụ `is_stock_item=false`).
- **Thanh toán NCC**: `supplier_payments`, `supplier_payment_allocations`, `supplier_adjustments`.

### 1.5 Kho & chuyển động
- `inventory_movements`: `purchase|sale|return_in|return_out|adjustment_pos|adjustment_neg|transfer_in|transfer_out`.
- `stock_adjustments`, `stock_adjustment_items` → trigger sinh movement tương ứng.

### 1.6 i18n & In ấn & Cấu hình cửa hàng
- i18n: `order_status_l10n`, `bill_status_l10n`, `payment_status_l10n`, `payment_term_l10n`, `inventory_movement_type_l10n` (+ optional `*_translations` cho tên/mô tả).
- `store_settings`: cấu hình cửa hàng (**store_name: “Đại lý vật tư nông nghiệp Sáu Hiệp”**, địa chỉ, liên hệ, kho mặc định, …).
- Views in ấn:
  - `invoice_print_header`, `invoice_print_lines`
  - `goods_issue_print_header`, `goods_issue_print_lines`
  - `gr_print_header`, `gr_print_lines`

### 1.7 View báo cáo tiện ích
- `stock_on_hand` (tồn theo `product_unit_id`, `warehouse_id`).
- `ar_balance_per_customer`, `ap_balance_per_supplier`.

### 1.8 ENUMS
- `profile_role`, `order_status`, `payment_term`, `payment_status`, `inventory_movement_type`, `bill_status`.

---

## 2) Luồng nghiệp vụ (B2C, không PO)

### 2.1 Nhập hàng (Goods Receipt) & AP
1. Tạo `goods_receipts` + `goods_receipt_items` (chọn kho) → **auto movement `purchase`** → tăng tồn.
2. Khi nhận **hóa đơn NCC**: nhập `supplier_bills` + `supplier_bill_items` → phát sinh **AP**.
3. Thanh toán NCC: `supplier_payments` + `supplier_payment_allocations`. Giảm trừ/hoàn tiền: `supplier_adjustments`.

### 2.2 Bán lẻ & AR
1. Tạo `orders` + `order_items`.
2. Xuất kho: chèn movement `sale` (có thể tự động theo trạng thái đơn nếu cần).
3. Thu tiền:
   - COD/prepaid: tạo `customer_payments` (`success`) + `customer_payment_allocations` vào đơn.
   - Credit (tùy dùng): để nợ, thu sau.

### 2.3 Trả hàng
- KH trả: movement `return_in` (+ tồn); điều chỉnh AR bằng `customer_adjustments` (dương) hoặc hoàn tiền (payment âm).
- Trả NCC: movement `return_out` (− tồn); điều chỉnh AP bằng `supplier_adjustments` (dương).

### 2.4 Điều chỉnh kho
- Kiểm kê/hư hỏng/hết hạn: `stock_adjustments` + `stock_adjustment_items` → movement `adjustment_pos/neg`.

### 2.5 Chuyển kho
- Tạo **cặp** movement `transfer_out` (kho A) & `transfer_in` (kho B); tổng tồn toàn hệ thống **không đổi**.

---

## 3) RBAC — Quyền gợi ý cho vai trò
- **admin**: full quyền (mọi `permissions`).
- **staff** (nhân viên): được
  - `CATALOG_READ`, `ORDERS_READ`, `ORDERS_WRITE`, `RECEIPTS_READ`, `RECEIPTS_WRITE`, `AR_READ`, `AR_ALLOCATE`, `REPORTS_VIEW`.
  - *Không có*: `CATALOG_WRITE`, `ORDERS_CANCEL`, `AR_ADJUST`, **tất cả AP***, `INVENTORY_ADJUST`, `WAREHOUSE_TRANSFER`, `DISCOUNTS_APPLY` (chưa cấp).
- Tùy chọn ràng buộc **theo kho** qua `warehouse_assignments`.

> App nên kiểm tra quyền ở cả BE (middleware) và FE (ẩn/disable nút).

---

## 4) Flyway — Thứ tự migrations
- **V1**: Enums + `profiles`
- **V2**: Catalog + reference
- **V3**: `orders`/`order_items` + AR
- **V4**: `warehouses` + Goods Receipt + AP
- **V5**: `inventory_movements` + `stock_adjustments` + triggers
- **V6**: Views `stock_on_hand`, `ar_balance_per_customer`, `ap_balance_per_supplier`
- **V7**: Seed tối thiểu (payment/shipping/kho Main)
- **V8** *(tùy chọn)*: i18n tiếng Việt
- **V9**: Seed demo danh mục/sản phẩm/quy cách + 1 Goods Receipt
- **V10**: `store_settings` + **views in** + 1 đơn B2C COD (đã xuất kho & thu đủ)
- **V11**: **RBAC** (`staff`, `permissions`, `role_permissions`, `warehouse_assignments`) + staff demo

---

## 5) Truy vấn kiểm tra nhanh
```sql
-- Tồn theo kho
select * from stock_on_hand order by product_unit_id, warehouse_id;

-- Tồn tại product_units
select sku, stock from product_units order by sku;

-- In ấn
select * from invoice_print_header order by order_id desc limit 1;
select * from invoice_print_lines where order_id = <order_id> order by line_no;

select * from goods_issue_print_header where order_id = <order_id>;
select * from goods_issue_print_lines  where order_id = <order_id> order by line_no;

select * from gr_print_header order by receipt_id desc limit 1;
select * from gr_print_lines   where receipt_id = <receipt_id> order by line_no;

-- RBAC
select * from profile_effective_permissions where email = 'staff.demo@example.com';
```

---

## 6) Giả định & Quy ước
- **Không tạo movement từ `supplier_bill_items`** (để tránh đếm đôi). Tăng tồn **chỉ** từ `goods_receipt_items` (và adjustments).
- `product_units.stock` là **derived** qua trigger; mọi thao tác tồn phải đi qua `inventory_movements`.
- **Ràng buộc xóa**: xóa phiếu nhập/điều chỉnh sẽ xóa items liên quan; đã sinh movement ⇒ tồn sẽ được đảo lại qua trigger.
- **Tiền tệ**: `VND`; làm tròn do FE/BE quyết định (chưa fix rule).
- **Thời gian**: lưu `timestamptz` UTC; FE hiển thị theo `vi-VN`.
- **Thuế/chiết khấu**: lưu ở dòng (line) và/tổng (header); chưa áp dụng thuế phức tạp.

---

## 7) Câu hỏi mở / Điểm cần xác nhận (để tránh đổi bảng về sau)
1. **Thuế (VAT)**: có áp dụng? Giá **đã gồm** hay **chưa gồm** VAT? Cần lưu **thuế suất per line** & tổng bill/invoice theo chuẩn nào?
2. **Chiết khấu**: cần **chiết khấu theo dòng**, **theo đơn**, **mã giảm giá** (coupons) rules thế nào? Có stack được không?
3. **Định mức giá**: có **giá theo bậc số lượng**/khuyến mãi theo thời gian không? Cần bảng price list?
4. **Định giá vốn**: có cần **giá vốn** (FIFO/LIFO/AVG) để tính **lãi gộp**? Nếu có, cần bảng **cost layers** cho movement.
5. **Lô/Hạn dùng**: có cần **batch/expiry**? Nếu có, phải thêm thuộc tính vào `goods_receipt_items` và `inventory_movements`.
6. **Số hóa đơn/đánh số chứng từ**: cần quy tắc numbering (tiền tố ngày/kho)? Chặn trùng `bill_no` theo NCC?
7. **Ràng buộc nhân viên**: staff có được **xóa/sửa** chứng từ không, hay **chỉ tạo**? Có cần **audit log** (who/when)?
8. **Giới hạn kho cho staff**: ràng buộc bắt buộc? Có cần check ở DB (trigger) ngoài app?
9. **Phí vận chuyển/đóng gói**: hạch toán ở đâu? Có cộng vào **giá vốn** hay chỉ là chi phí?
10. **Trả hàng**: quy trình hoàn tiền/điều chỉnh AR/AP mong muốn thế nào? Có cần **Credit Note** rõ ràng không?
11. **Thanh toán**: tích hợp cổng nào (VNPAY, Momo…)? Cần **webhook logs**/idempotency?
12. **Chuyển kho**: có cần **phiếu chuyển kho** riêng + in ấn? Có cần duyệt?
13. **i18n**: chỉ tiếng Việt, hay cần thêm **tiếng Anh**? Nếu có, dùng bảng `*_translations` sẵn có.
14. **Upload chứng từ**: cần bảng **attachments** (lưu ảnh hóa đơn NCC, ký nhận giao hàng)?
15. **Xóa mềm (soft delete)**: có muốn bật cho các chứng từ chính (orders, receipts, bills)?
16. **Ràng buộc tồn âm**: có cho phép tồn âm khi bán không? (Hiện tại **không chặn** ở DB.)
17. **Sao lưu & khôi phục**: quy trình backup/restore? Có yêu cầu **multi‑tenant** trong tương lai không?
18. **Số lượng lớn**: có cần **pagination, search index** (SKU, barcode) tối ưu hơn?

> Trả lời dần các câu trên sẽ giúp **ổn định schema** lâu dài, tránh đổi bảng sau này.

---

## 8) Hướng dẫn dùng lại tài liệu này
- Khi mở lại dự án với ChatGPT, **upload file `.md` này trước** và nói: “Đây là context của dự án Sáu Hiệp (B2C Phase 2 v11). Tiếp tục giúp mình…”

