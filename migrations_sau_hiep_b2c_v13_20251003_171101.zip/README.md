
# Flyway Migrations — Phase 2 (B2C, no PO, keep Goods Receipts)

**Database:** PostgreSQL

**Order:** V1 → V10

- V1__enums_and_profiles.sql
- V2__catalog_and_reference.sql
- V3__sales_orders_and_AR.sql
- V4__AP_goods_receipts_and_bills.sql
- V5__inventory_movements_and_triggers.sql
- V6__views_and_reports.sql
- V7__seed_minimal.sql
- V8__i18n_translations.sql (optional but recommended)
- V9__seed_sample_catalog_and_goods_receipt.sql
- V10__b2c_store_settings_print_views_and_demo_order.sql

## Notes
- Uses `gen_random_uuid()` from extension `pgcrypto`.
- Inventory increases come from **goods_receipt_items** (movement `purchase` via trigger).
- `product_units.stock` is kept in sync by triggers from `inventory_movements`.
- Printing views read **store_settings** for shop header and i18n tables for Vietnamese labels.
