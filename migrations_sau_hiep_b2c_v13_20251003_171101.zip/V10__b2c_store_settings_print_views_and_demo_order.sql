
-- V10: B2C store settings, printing views, and demo B2C order fully paid

-- ===== Store settings =====
create table if not exists store_settings (
  id bigserial primary key,
  store_name text not null,
  legal_name text,
  phone text,
  email text,
  address text,
  tax_id text,
  default_warehouse_id bigint references warehouses(id) on delete set null,
  currency char(3) not null default 'VND',
  locale text not null default 'vi-VN',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

do $$
declare wh_id bigint;
begin
  select id into wh_id from warehouses where name='Main' limit 1;
  if not exists (select 1 from store_settings) then
    insert into store_settings(store_name, default_warehouse_id)
    values ('Đại lý vật tư nông nghiệp Sáu Hiệp', wh_id);
  else
    update store_settings set store_name='Đại lý vật tư nông nghiệp Sáu Hiệp'
    where id in (select id from store_settings order by id limit 1);
  end if;
end $$;

-- ===== Printing views =====

-- Invoice (Hóa đơn bán lẻ) header
create or replace view invoice_print_header as
with ss as (select * from store_settings order by id desc limit 1),
lbl as (select * from order_status_l10n where locale='vi')
select
  o.id as order_id,
  o.created_at as order_date,
  o.status,
  coalesce(lbl.label, o.status::text) as status_label_vi,
  o.payment_term,
  (select label from payment_term_l10n where code=(o.payment_term::text) and locale='vi') as payment_term_label_vi,
  (o.total_amount - o.discount_total) as net_total,
  p.name as buyer_name,
  p.phone as buyer_phone,
  p.address as buyer_address,
  ss.store_name,
  ss.address as store_address,
  ss.phone as store_phone,
  ss.email as store_email,
  ss.tax_id as store_tax_id
from orders o
left join profiles p on p.id = o.buyer_id
left join ss on true
left join lbl on lbl.code = (o.status::text);

-- Invoice line items
create or replace view invoice_print_lines as
select
  oi.order_id,
  row_number() over (partition by oi.order_id order by oi.id) as line_no,
  pu.sku,
  pr.name as product_name,
  pu.size_label,
  oi.quantity,
  oi.price,
  oi.discount_amount,
  (oi.quantity * oi.price - oi.discount_amount) as line_total
from order_items oi
join product_units pu on pu.id = oi.product_unit_id
join products pr on pr.id = pu.product_id;

-- Goods Issue (Phiếu xuất kho theo đơn bán)
-- Uses order info; you can filter where orders.status in ('confirmed','completed')
create or replace view goods_issue_print_header as
with ss as (select * from store_settings order by id desc limit 1)
select
  o.id as order_id,
  o.created_at as issue_date,
  p.name as receiver_name,
  p.phone as receiver_phone,
  p.address as receiver_address,
  ss.store_name,
  ss.address as store_address,
  ss.phone as store_phone
from orders o
left join profiles p on p.id = o.buyer_id
left join ss on true;

create or replace view goods_issue_print_lines as
select
  oi.order_id,
  row_number() over (partition by oi.order_id order by oi.id) as line_no,
  pu.sku,
  pr.name as product_name,
  pu.size_label,
  oi.quantity
from order_items oi
join product_units pu on pu.id = oi.product_unit_id
join products pr on pr.id = pu.product_id;

-- Goods Receipt (Phiếu nhập kho NCC)
create or replace view gr_print_header as
with ss as (select * from store_settings order by id desc limit 1)
select
  gr.id as receipt_id,
  gr.received_at as received_at,
  s.name as supplier_name,
  s.phone as supplier_phone,
  s.address as supplier_address,
  w.name as warehouse_name,
  ss.store_name,
  ss.address as store_address,
  ss.phone as store_phone,
  ss.email as store_email
from goods_receipts gr
join profiles s on s.id = gr.supplier_id
join warehouses w on w.id = gr.warehouse_id
left join ss on true;

create or replace view gr_print_lines as
select
  gri.receipt_id,
  row_number() over (partition by gri.receipt_id order by gri.id) as line_no,
  pu.sku,
  pr.name as product_name,
  pu.size_label,
  gri.quantity
from goods_receipt_items gri
join product_units pu on pu.id = gri.product_unit_id
join products pr on pr.id = pu.product_id;

-- ===== Demo B2C order (COD) fully paid and issued from Main warehouse =====
insert into profiles(email, name, phone, address, role)
values ('khach.le@example.com','Khách lẻ (demo)','0909123456','Trà Vinh','customer')
on conflict (email) do nothing;

with buyer as (select id as buyer_id from profiles where email='khach.le@example.com' limit 1),
pu as (
  select
    (select id from product_units where sku='NPK-16168-25KG') as npk_id,
    (select price from product_units where sku='NPK-16168-25KG') as npk_price,
    (select id from product_units where sku='KARATE-100ML') as krt_id,
    (select price from product_units where sku='KARATE-100ML') as krt_price
),
totals as (select (3*pu.npk_price + 2*pu.krt_price)::numeric as total_amount from pu),
ord as (
  insert into orders(buyer_id,total_amount,discount_total,status,shipping_method_id,payment_method_id,payment_term)
  select buyer.buyer_id, totals.total_amount, 0, 'confirmed',
         (select id from shipping_methods where name='Standard'),
         (select id from payment_methods where name='COD'),
         'cod'
  from buyer, totals
  returning id, buyer_id
),
items as (
  insert into order_items(order_id, product_unit_id, quantity, price)
  select (select id from ord), pu.npk_id, 3, pu.npk_price from pu
  union all
  select (select id from ord), pu.krt_id, 2, pu.krt_price from pu
  returning order_id
),
mov as (
  insert into inventory_movements(product_unit_id, warehouse_id, type, quantity, ref_table, ref_id)
  select (select id from product_units where sku='NPK-16168-25KG'),
         (select id from warehouses where name='Main' limit 1),
         'sale', 3, 'orders', (select id from ord)
  union all
  select (select id from product_units where sku='KARATE-100ML'),
         (select id from warehouses where name='Main' limit 1),
         'sale', 2, 'orders', (select id from ord)
  returning ref_id
),
pay as (
  insert into customer_payments(payer_id, amount, method_id, status, paid_at, note)
  select (select buyer_id from ord),
         (select total_amount from totals),
         (select id from payment_methods where name='COD'),
         'success', now(), 'COD collected (demo)'
  returning id
)
insert into customer_payment_allocations(payment_id, order_id, allocated_amount)
select (select id from pay), (select id from ord), (select total_amount from totals);

update orders set status='completed' where id in (select id from ord);
