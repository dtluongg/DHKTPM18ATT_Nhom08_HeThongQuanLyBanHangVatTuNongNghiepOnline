
-- V11: Add 'staff' role and role-based permissions scaffolding (RBAC)
-- Safe to apply on top of V1..V10

-- 1) Extend enum profile_role with 'staff' if not exists
do $$
begin
  if not exists (
    select 1 from pg_enum e
    join pg_type t on t.oid = e.enumtypid
    where t.typname = 'profile_role' and e.enumlabel = 'staff'
  ) then
    alter type profile_role add value 'staff';
  end if;
end $$;

-- 2) Permission catalog
create table if not exists permissions (
  code text primary key,             -- e.g., 'ORDERS_READ'
  description text
);

create table if not exists role_permissions (
  role profile_role not null,
  permission_code text not null references permissions(code) on delete cascade,
  primary key (role, permission_code)
);

-- 3) Seed a recommended permission set
insert into permissions(code, description) values
  ('CATALOG_READ', 'Xem danh mục & sản phẩm'),
  ('CATALOG_WRITE', 'Thêm/sửa/xóa danh mục & sản phẩm'),
  ('ORDERS_READ', 'Xem đơn hàng'),
  ('ORDERS_WRITE', 'Tạo/sửa đơn hàng, thêm dòng'),
  ('ORDERS_CANCEL', 'Hủy đơn hàng'),
  ('AR_READ', 'Xem công nợ khách hàng'),
  ('AR_ALLOCATE', 'Phân bổ thanh toán vào đơn'),
  ('AR_ADJUST', 'Điều chỉnh AR (credit note/ghi nợ)'),
  ('AP_READ', 'Xem công nợ NCC'),
  ('AP_WRITE', 'Thêm hóa đơn/phiếu chi NCC'),
  ('AP_ALLOCATE', 'Phân bổ thanh toán vào hóa đơn NCC'),
  ('AP_ADJUST', 'Điều chỉnh AP (credit note/ghi nợ)'),
  ('RECEIPTS_READ', 'Xem phiếu nhập kho'),
  ('RECEIPTS_WRITE', 'Tạo phiếu nhập kho'),
  ('INVENTORY_ADJUST', 'Tạo phiếu điều chỉnh kho'),
  ('WAREHOUSE_TRANSFER', 'Chuyển kho nội bộ'),
  ('DISCOUNTS_APPLY', 'Áp mã giảm giá/chiết khấu'),
  ('REPORTS_VIEW', 'Xem báo cáo')
on conflict (code) do nothing;

-- 4) Default grants for 'admin' and 'staff'
-- Admin: grant all permissions above
insert into role_permissions(role, permission_code)
select 'admin'::profile_role, p.code from permissions p
on conflict do nothing;

-- Staff: limited set
insert into role_permissions(role, permission_code) values
  ('staff','CATALOG_READ'),
  ('staff','ORDERS_READ'),
  ('staff','ORDERS_WRITE'),
  ('staff','RECEIPTS_READ'),
  ('staff','RECEIPTS_WRITE'),
  ('staff','AR_READ'),
  ('staff','AR_ALLOCATE'),
  ('staff','REPORTS_VIEW')
on conflict do nothing;

-- Explicitly deny by omission for staff:
-- CATALOG_WRITE, ORDERS_CANCEL, AR_ADJUST, AP_*, INVENTORY_ADJUST, WAREHOUSE_TRANSFER, DISCOUNTS_APPLY

-- 5) Optional: Assign staff to specific warehouse(s) for operational scope
create table if not exists warehouse_assignments (
  id bigserial primary key,
  profile_id uuid not null references profiles(id) on delete cascade,
  warehouse_id bigint not null references warehouses(id) on delete cascade,
  unique (profile_id, warehouse_id)
);

-- 6) Optional sample staff user (for dev/testing)
insert into profiles(email, name, phone, address, role)
values ('staff.demo@example.com','Nhân viên bán hàng (demo)','0909888777','Trà Vinh','staff')
on conflict (email) do nothing;

-- Assign staff to Main warehouse if exists
do $$
declare staff_id uuid; wh_id bigint;
begin
  select id into staff_id from profiles where email='staff.demo@example.com' limit 1;
  select id into wh_id from warehouses where name='Main' limit 1;
  if staff_id is not null and wh_id is not null then
    insert into warehouse_assignments(profile_id, warehouse_id)
    values (staff_id, wh_id)
    on conflict do nothing;
  end if;
end $$;

-- 7) Helper view: list effective permissions per user (by role)
create or replace view profile_effective_permissions as
select
  pr.id as profile_id,
  pr.email,
  pr.name,
  pr.role,
  rp.permission_code
from profiles pr
join role_permissions rp on rp.role = pr.role;
