
-- V13__vat_rate_per_product_and_sugar_halfkg.sql
-- Purpose:
--  1) Add VAT rate per product (percent), default 10.0 (VAT already included in price model).
--  2) Snapshot VAT rate per order item, and store per-line VAT amount to enable correct per-item VAT totals.
--  3) Provide a helper function to (re)compute einvoice totals from order items.
--  4) Seed demo: add product unit 'Đường trắng – 0.5kg' if product 'Đường trắng' exists.

begin;

-- 1) VAT rate per product (percent, e.g., 0, 5, 8, 10)
do $$
begin
  if not exists (
    select 1 from information_schema.columns 
    where table_name='products' and column_name='vat_rate'
  ) then
    alter table products 
      add column vat_rate numeric not null default 10
      check (vat_rate >= 0 and vat_rate <= 20);
  end if;
end $$;

comment on column products.vat_rate is 'VAT rate (%) at product level, e.g., 0, 5, 8, 10. Price fields are VAT-included.';

-- 2) Snapshot VAT per order item (for correct totals when items have different rates)
do $$
begin
  if not exists (
    select 1 from information_schema.columns 
    where table_name='order_items' and column_name='vat_rate'
  ) then
    alter table order_items add column vat_rate numeric; -- percent
  end if;
  if not exists (
    select 1 from information_schema.columns 
    where table_name='order_items' and column_name='vat_amount'
  ) then
    alter table order_items add column vat_amount numeric; -- VAT amount for this line (VAT-in-price)
  end if;
end $$;

comment on column order_items.vat_rate is 'Snapshot of product VAT rate (%) at sale time.';
comment on column order_items.vat_amount is 'Per-line VAT amount (derived from VAT-included price).';

-- 2.1) Backfill vat_rate for historical items (if any): copy from product vat_rate
update order_items oi
set vat_rate = p.vat_rate
from product_units pu 
join products p on p.id = pu.product_id
where oi.product_unit_id = pu.id
  and oi.vat_rate is null;

-- 2.2) Recalculate vat_amount for historical lines based on VAT-included model:
-- VAT_amount = round(line_total * (vat_rate / (100 + vat_rate)), 0)
update order_items
set vat_amount = round(
  case 
    when coalesce(vat_rate, 0) > 0 then line_total * (vat_rate / (100 + vat_rate))
    else 0
  end
, 0)
where vat_amount is null;

-- 3) Helper function: recompute einvoice totals from order items (supports mixed VAT rates)
create or replace function recompute_einvoice_totals(p_einvoice_id bigint)
returns void language plpgsql as $$
declare
  v_order_id bigint;
  v_grand_total numeric;
  v_tax_total numeric;
  v_subtotal numeric;
begin
  select e.order_id into v_order_id from einvoices e where e.id = p_einvoice_id;
  if v_order_id is null then
    raise exception 'einvoice % not found', p_einvoice_id;
  end if;

  select o.grand_total into v_grand_total from orders o where o.id = v_order_id;

  select coalesce(sum(oi.vat_amount),0) into v_tax_total
  from order_items oi
  where oi.order_id = v_order_id;

  v_subtotal := coalesce(v_grand_total,0) - v_tax_total;

  update einvoices e
  set tax_total = v_tax_total,
      subtotal = v_subtotal,
      updated_at = now()
  where e.id = p_einvoice_id;
end $$;

comment on function recompute_einvoice_totals is 'Recalculates subtotal and tax_total on einvoices from per-line VAT amounts.';

-- 4) Seed demo: add 0.5kg unit for "Đường trắng" if product exists
do $$
declare
  v_product_id bigint;
  v_exists boolean;
begin
  select id into v_product_id from products where lower(name) = lower('Đường trắng') limit 1;
  if v_product_id is not null then
    select exists (
      select 1 from product_units 
      where product_id = v_product_id and lower(size_label) = lower('0.5kg')
    ) into v_exists;

    if not v_exists then
      insert into product_units (product_id, size_label, uom, net_qty, price, sku, barcode, is_active)
      values (v_product_id, '0.5kg', 'kg', 0.5, 0, null, null, true);
    end if;
  end if;
end $$;

commit;
