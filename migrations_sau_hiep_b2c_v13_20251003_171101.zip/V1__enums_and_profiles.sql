
-- V1: Enums & Profiles (unified)
create extension if not exists pgcrypto;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'profile_role') then
    create type profile_role as enum ('customer','agent','supplier','admin');
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'order_status') then
    create type order_status as enum ('pending','confirmed','shipped','completed','cancelled');
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'payment_term') then
    create type payment_term as enum ('prepaid','cod','credit');
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'payment_status') then
    create type payment_status as enum ('pending','success','failed','void');
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'inventory_movement_type') then
    create type inventory_movement_type as enum (
      'purchase','sale','return_in','return_out','adjustment_pos','adjustment_neg','transfer_in','transfer_out'
    );
  end if;
end $$;

do $$ begin
  if not exists (select 1 from pg_type where typname = 'bill_status') then
    create type bill_status as enum ('open','partially_paid','paid','void');
  end if;
end $$;

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  email varchar unique,
  password_hash text,
  name varchar,
  phone varchar,
  address text,
  role profile_role not null default 'customer',
  note text,
  is_active boolean not null default true,
  last_login_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_role on profiles(role);
