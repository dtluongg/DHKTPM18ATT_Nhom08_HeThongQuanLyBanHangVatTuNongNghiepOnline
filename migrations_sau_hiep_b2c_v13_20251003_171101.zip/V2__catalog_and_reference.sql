
-- V2: Catalog and Reference

create table if not exists categories (
  id bigserial primary key,
  name varchar not null,
  slug varchar unique,
  description text
);

create table if not exists brands (
  id bigserial primary key,
  name varchar not null,
  slug varchar unique,
  country varchar
);

create table if not exists products (
  id bigserial primary key,
  category_id bigint references categories(id) on delete set null,
  brand_id bigint references brands(id) on delete set null,
  name varchar not null,
  slug varchar unique,
  description text,
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_products_category on products(category_id);
create index if not exists idx_products_brand on products(brand_id);
create index if not exists idx_products_active on products(is_active);

create table if not exists product_units (
  id bigserial primary key,
  product_id bigint not null references products(id) on delete cascade,
  unit varchar,
  size_label varchar,
  net_qty numeric,
  uom varchar,
  price numeric not null,
  sku varchar unique,
  barcode varchar unique,
  stock integer not null default 0,
  is_active boolean not null default true
);

create index if not exists idx_product_units_product on product_units(product_id);
create index if not exists idx_product_units_active on product_units(is_active);

create table if not exists payment_methods (
  id bigserial primary key,
  name varchar not null unique
);

create table if not exists shipping_methods (
  id bigserial primary key,
  name varchar not null unique,
  description text
);

create table if not exists coupons (
  id bigserial primary key,
  code varchar not null unique,
  discount_type varchar,
  discount_value numeric,
  min_order_total numeric,
  expiry_date date,
  usage_limit integer
);

create table if not exists banners (
  id bigserial primary key,
  image_url text,
  title varchar,
  is_active boolean not null default true,
  position integer
);
