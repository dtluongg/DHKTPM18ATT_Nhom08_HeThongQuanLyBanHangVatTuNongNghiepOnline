
-- V3: Sales Orders & AR

create table if not exists orders (
  id bigserial primary key,
  buyer_id uuid references profiles(id) on delete set null,
  total_amount numeric not null,
  discount_total numeric not null default 0,
  status order_status not null default 'pending',
  shipping_method_id bigint references shipping_methods(id) on delete set null,
  payment_method_id bigint references payment_methods(id) on delete set null,
  coupon_id bigint references coupons(id) on delete set null,
  payment_term payment_term not null default 'prepaid',
  created_at timestamptz not null default now()
);

create index if not exists idx_orders_buyer on orders(buyer_id);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_created_at on orders(created_at);

create table if not exists order_items (
  id bigserial primary key,
  order_id bigint not null references orders(id) on delete cascade,
  product_unit_id bigint not null references product_units(id) on delete restrict,
  quantity integer not null,
  price numeric not null,
  discount_amount numeric not null default 0
);

create index if not exists idx_order_items_order on order_items(order_id);
create index if not exists idx_order_items_product_unit on order_items(product_unit_id);

create table if not exists customer_payments (
  id bigserial primary key,
  payer_id uuid not null references profiles(id) on delete restrict,
  amount numeric not null,
  method_id bigint references payment_methods(id) on delete set null,
  status payment_status not null default 'success',
  paid_at timestamptz,
  provider_txn_id varchar,
  note text,
  created_at timestamptz not null default now()
);

create index if not exists idx_customer_payments_payer on customer_payments(payer_id);
create index if not exists idx_customer_payments_paid_at on customer_payments(paid_at);

create table if not exists customer_payment_allocations (
  id bigserial primary key,
  payment_id bigint not null references customer_payments(id) on delete cascade,
  order_id bigint not null references orders(id) on delete cascade,
  allocated_amount numeric not null check (allocated_amount > 0)
);

create index if not exists idx_cpa_payment on customer_payment_allocations(payment_id);
create index if not exists idx_cpa_order on customer_payment_allocations(order_id);

create table if not exists customer_adjustments (
  id bigserial primary key,
  buyer_id uuid not null references profiles(id) on delete restrict,
  order_id bigint references orders(id) on delete set null,
  amount numeric not null,
  reason varchar,
  created_at timestamptz not null default now()
);

create index if not exists idx_cadj_buyer on customer_adjustments(buyer_id);
create index if not exists idx_cadj_order on customer_adjustments(order_id);
