
-- V4: Goods Receipts (no PO) & Supplier Bills (AP)

create table if not exists warehouses (
  id bigserial primary key,
  name varchar not null,
  address text
);

create table if not exists goods_receipts (
  id bigserial primary key,
  supplier_id uuid not null references profiles(id) on delete restrict,
  warehouse_id bigint not null references warehouses(id) on delete restrict,
  received_at timestamptz not null default now(),
  note text
);

create index if not exists idx_goods_receipts_supplier on goods_receipts(supplier_id);
create index if not exists idx_goods_receipts_warehouse on goods_receipts(warehouse_id);

create table if not exists goods_receipt_items (
  id bigserial primary key,
  receipt_id bigint not null references goods_receipts(id) on delete cascade,
  product_unit_id bigint not null references product_units(id) on delete restrict,
  quantity integer not null check (quantity > 0)
);

create index if not exists idx_gr_items_receipt on goods_receipt_items(receipt_id);
create index if not exists idx_gr_items_product_unit on goods_receipt_items(product_unit_id);

create table if not exists supplier_bills (
  id bigserial primary key,
  supplier_id uuid not null references profiles(id) on delete restrict,
  bill_no varchar,
  bill_date date not null,
  due_date date,
  status bill_status not null default 'open',
  subtotal numeric not null,
  discount_total numeric not null default 0,
  tax_total numeric not null default 0,
  total_amount numeric not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_supplier_bills_supplier on supplier_bills(supplier_id);
create index if not exists idx_supplier_bills_status on supplier_bills(status);
create index if not exists idx_supplier_bills_dates on supplier_bills(bill_date, due_date);

create table if not exists supplier_bill_items (
  id bigserial primary key,
  bill_id bigint not null references supplier_bills(id) on delete cascade,
  product_unit_id bigint null references product_units(id) on delete set null,
  description text,
  quantity numeric not null default 1,
  uom varchar,
  unit_price numeric not null,
  line_discount numeric not null default 0,
  tax_rate numeric not null default 0,
  is_stock_item boolean not null default true
);

create index if not exists idx_sbill_items_bill on supplier_bill_items(bill_id);
create index if not exists idx_sbill_items_product_unit on supplier_bill_items(product_unit_id);

create table if not exists supplier_payments (
  id bigserial primary key,
  payee_id uuid not null references profiles(id) on delete restrict,
  amount numeric not null,
  method_id bigint references payment_methods(id) on delete set null,
  status payment_status not null default 'success',
  paid_at timestamptz,
  note text,
  created_at timestamptz not null default now()
);

create index if not exists idx_supplier_payments_payee on supplier_payments(payee_id);
create index if not exists idx_supplier_payments_paid_at on supplier_payments(paid_at);

create table if not exists supplier_payment_allocations (
  id bigserial primary key,
  payment_id bigint not null references supplier_payments(id) on delete cascade,
  bill_id bigint not null references supplier_bills(id) on delete cascade,
  allocated_amount numeric not null check (allocated_amount > 0)
);

create index if not exists idx_spa_payment on supplier_payment_allocations(payment_id);
create index if not exists idx_spa_bill on supplier_payment_allocations(bill_id);

create table if not exists supplier_adjustments (
  id bigserial primary key,
  supplier_id uuid not null references profiles(id) on delete restrict,
  bill_id bigint references supplier_bills(id) on delete set null,
  amount numeric not null,
  reason varchar,
  created_at timestamptz not null default now()
);

create index if not exists idx_sadj_supplier on supplier_adjustments(supplier_id);
create index if not exists idx_sadj_bill on supplier_adjustments(bill_id);
