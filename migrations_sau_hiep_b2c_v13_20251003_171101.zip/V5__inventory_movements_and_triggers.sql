
-- V5: Inventory Movements, Adjustments, and Triggers

create table if not exists inventory_movements (
  id bigserial primary key,
  product_unit_id bigint not null references product_units(id) on delete restrict,
  warehouse_id bigint not null references warehouses(id) on delete restrict,
  type inventory_movement_type not null,
  quantity integer not null check (quantity > 0),
  ref_table varchar,
  ref_id bigint,
  created_at timestamptz not null default now()
);

create index if not exists idx_movements_product on inventory_movements(product_unit_id);
create index if not exists idx_movements_warehouse on inventory_movements(warehouse_id);
create index if not exists idx_movements_type on inventory_movements(type);
create index if not exists idx_movements_ref on inventory_movements(ref_table, ref_id);

create table if not exists stock_adjustments (
  id bigserial primary key,
  warehouse_id bigint not null references warehouses(id) on delete restrict,
  reason varchar,
  created_at timestamptz not null default now()
);

create table if not exists stock_adjustment_items (
  id bigserial primary key,
  adjustment_id bigint not null references stock_adjustments(id) on delete cascade,
  product_unit_id bigint not null references product_units(id) on delete restrict,
  diff_qty integer not null
);

create or replace function apply_product_unit_stock_on_movement_ins()
returns trigger language plpgsql as $$
begin
  if NEW.type in ('transfer_in','transfer_out') then
    return NEW;
  end if;
  if NEW.type in ('sale','return_out','adjustment_neg') then
    update product_units set stock = stock - NEW.quantity where id = NEW.product_unit_id;
  else
    update product_units set stock = stock + NEW.quantity where id = NEW.product_unit_id;
  end if;
  return NEW;
end $$;

create or replace function apply_product_unit_stock_on_movement_upd()
returns trigger language plpgsql as $$
begin
  if OLD.type not in ('transfer_in','transfer_out') then
    if OLD.type in ('sale','return_out','adjustment_neg') then
      update product_units set stock = stock + OLD.quantity where id = OLD.product_unit_id;
    else
      update product_units set stock = stock - OLD.quantity where id = OLD.product_unit_id;
    end if;
  end if;
  if NEW.type not in ('transfer_in','transfer_out') then
    if NEW.type in ('sale','return_out','adjustment_neg') then
      update product_units set stock = stock - NEW.quantity where id = NEW.product_unit_id;
    else
      update product_units set stock = stock + NEW.quantity where id = NEW.product_unit_id;
    end if;
  end if;
  return NEW;
end $$;

create or replace function apply_product_unit_stock_on_movement_del()
returns trigger language plpgsql as $$
begin
  if OLD.type in ('transfer_in','transfer_out') then
    return OLD;
  end if;
  if OLD.type in ('sale','return_out','adjustment_neg') then
    update product_units set stock = stock + OLD.quantity where id = OLD.product_unit_id;
  else
    update product_units set stock = stock - OLD.quantity where id = OLD.product_unit_id;
  end if;
  return OLD;
end $$;

drop trigger if exists trg_movements_after_ins on inventory_movements;
create trigger trg_movements_after_ins
after insert on inventory_movements
for each row execute function apply_product_unit_stock_on_movement_ins();

drop trigger if exists trg_movements_after_upd on inventory_movements;
create trigger trg_movements_after_upd
after update on inventory_movements
for each row execute function apply_product_unit_stock_on_movement_upd();

drop trigger if exists trg_movements_after_del on inventory_movements;
create trigger trg_movements_after_del
after delete on inventory_movements
for each row execute function apply_product_unit_stock_on_movement_del();

create or replace function ins_movement_from_receipt_item()
returns trigger language plpgsql as $$
declare
  wh_id bigint;
begin
  select warehouse_id into wh_id from goods_receipts where id = NEW.receipt_id;
  insert into inventory_movements(product_unit_id, warehouse_id, type, quantity, ref_table, ref_id, created_at)
  values (NEW.product_unit_id, wh_id, 'purchase', NEW.quantity, 'goods_receipt_items', NEW.id, now());
  return NEW;
end $$;

drop trigger if exists trg_gr_items_after_ins on goods_receipt_items;
create trigger trg_gr_items_after_ins
after insert on goods_receipt_items
for each row execute function ins_movement_from_receipt_item();

create or replace function ins_movement_from_adjustment_item()
returns trigger language plpgsql as $$
declare
  wh_id bigint;
  qty integer;
  mtype inventory_movement_type;
begin
  select warehouse_id into wh_id from stock_adjustments where id = NEW.adjustment_id;
  if NEW.diff_qty = 0 then return NEW; end if;
  if NEW.diff_qty > 0 then
    mtype := 'adjustment_pos'; qty := NEW.diff_qty;
  else
    mtype := 'adjustment_neg'; qty := abs(NEW.diff_qty);
  end if;
  insert into inventory_movements(product_unit_id, warehouse_id, type, quantity, ref_table, ref_id, created_at)
  values (NEW.product_unit_id, wh_id, mtype, qty, 'stock_adjustment_items', NEW.id, now());
  return NEW;
end $$;

drop trigger if exists trg_sai_after_ins on stock_adjustment_items;
create trigger trg_sai_after_ins
after insert on stock_adjustment_items
for each row execute function ins_movement_from_adjustment_item();
