
-- V6: Utility views

create or replace view stock_on_hand as
select
  m.product_unit_id,
  m.warehouse_id,
  sum(case
        when m.type in ('purchase','return_in','adjustment_pos','transfer_in') then m.quantity
        when m.type in ('sale','return_out','adjustment_neg','transfer_out') then -m.quantity
        else 0
      end) as qty
from inventory_movements m
group by m.product_unit_id, m.warehouse_id;

create or replace view ar_balance_per_customer as
with ord as (
  select o.id, o.buyer_id, (o.total_amount - o.discount_total) as net_total
  from orders o where o.status <> 'cancelled'
),
pay as (
  select cpa.order_id, sum(cpa.allocated_amount) as paid_total
  from customer_payment_allocations cpa
  group by cpa.order_id
),
adj as (
  select ca.buyer_id,
         sum(case when ca.amount > 0 then ca.amount else 0 end) as adj_positive,
         sum(case when ca.amount < 0 then -ca.amount else 0 end) as adj_negative
  from customer_adjustments ca
  group by ca.buyer_id
)
select
  p.id as buyer_id,
  p.name,
  coalesce(sum(ord.net_total),0)
  - coalesce(sum(pay.paid_total),0)
  - coalesce(max(adj.adj_positive),0)
  + coalesce(max(adj.adj_negative),0) as balance
from profiles p
left join ord on ord.buyer_id = p.id
left join pay on pay.order_id = ord.id
left join adj on adj.buyer_id = p.id
where p.role in ('customer','agent')
group by p.id, p.name;

create or replace view ap_balance_per_supplier as
with bills as (
  select b.id, b.supplier_id, b.total_amount
  from supplier_bills b where b.status <> 'void'
),
alloc as (
  select spa.bill_id, sum(spa.allocated_amount) as alloc_total
  from supplier_payment_allocations spa
  group by spa.bill_id
),
sadj as (
  select sa.supplier_id,
         sum(case when sa.amount > 0 then sa.amount else 0 end) as adj_positive,
         sum(case when sa.amount < 0 then -sa.amount else 0 end) as adj_negative
  from supplier_adjustments sa
  group by sa.supplier_id
)
select
  p.id as supplier_id,
  p.name,
  coalesce(sum(bills.total_amount),0)
  - coalesce(sum(alloc.alloc_total),0)
  - coalesce(max(sadj.adj_positive),0)
  + coalesce(max(sadj.adj_negative),0) as balance
from profiles p
left join bills on bills.supplier_id = p.id
left join alloc on alloc.bill_id = bills.id
left join sadj on sadj.supplier_id = p.id
where p.role = 'supplier'
group by p.id, p.name;
