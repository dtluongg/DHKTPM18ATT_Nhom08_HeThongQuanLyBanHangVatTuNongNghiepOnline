
-- V7: Minimal seeds

insert into payment_methods(name) values
  ('COD') on conflict (name) do nothing;
insert into payment_methods(name) values
  ('Bank Transfer') on conflict (name) do nothing;
insert into payment_methods(name) values
  ('Online Gateway') on conflict (name) do nothing;

insert into shipping_methods(name, description) values
  ('Standard', 'Giao tiêu chuẩn')
  on conflict (name) do nothing;
insert into shipping_methods(name, description) values
  ('Express', 'Giao nhanh')
  on conflict (name) do nothing;

insert into warehouses(name) values
  ('Main') on conflict do nothing;
