
-- V8: i18n (Vietnamese labels)

create table if not exists order_status_l10n (
  code text not null,
  locale text not null,
  label text not null,
  primary key (code, locale)
);

create table if not exists bill_status_l10n (
  code text not null,
  locale text not null,
  label text not null,
  primary key (code, locale)
);

create table if not exists payment_status_l10n (
  code text not null,
  locale text not null,
  label text not null,
  primary key (code, locale)
);

create table if not exists payment_term_l10n (
  code text not null,
  locale text not null,
  label text not null,
  primary key (code, locale)
);

create table if not exists inventory_movement_type_l10n (
  code text not null,
  locale text not null,
  label text not null,
  primary key (code, locale)
);

insert into order_status_l10n(code, locale, label) values
  ('pending','vi','Chờ xử lý'),
  ('confirmed','vi','Đã xác nhận'),
  ('shipped','vi','Đã gửi hàng'),
  ('completed','vi','Hoàn tất'),
  ('cancelled','vi','Đã hủy')
on conflict (code, locale) do update set label=excluded.label;

insert into bill_status_l10n(code, locale, label) values
  ('open','vi','Chưa thanh toán'),
  ('partially_paid','vi','Thanh toán một phần'),
  ('paid','vi','Đã thanh toán'),
  ('void','vi','Vô hiệu')
on conflict (code, locale) do update set label=excluded.label;

insert into payment_status_l10n(code, locale, label) values
  ('pending','vi','Đang chờ'),
  ('success','vi','Thành công'),
  ('failed','vi','Thất bại'),
  ('void','vi','Hủy')
on conflict (code, locale) do update set label=excluded.label;

insert into payment_term_l10n(code, locale, label) values
  ('prepaid','vi','Trả trước'),
  ('cod','vi','Thanh toán khi nhận'),
  ('credit','vi','Mua nợ')
on conflict (code, locale) do update set label=excluded.label;

insert into inventory_movement_type_l10n(code, locale, label) values
  ('purchase','vi','Nhập mua'),
  ('sale','vi','Xuất bán'),
  ('return_in','vi','Nhập trả'),
  ('return_out','vi','Xuất trả NCC'),
  ('adjustment_pos','vi','Điều chỉnh tăng'),
  ('adjustment_neg','vi','Điều chỉnh giảm'),
  ('transfer_in','vi','Nhập chuyển kho'),
  ('transfer_out','vi','Xuất chuyển kho')
on conflict (code, locale) do update set label=excluded.label;

-- Optional translation tables for names/descriptions
create table if not exists category_translations (
  id bigserial primary key,
  category_id bigint not null references categories(id) on delete cascade,
  locale text not null,
  name text,
  description text,
  unique (category_id, locale)
);

create table if not exists brand_translations (
  id bigserial primary key,
  brand_id bigint not null references brands(id) on delete cascade,
  locale text not null,
  name text,
  country text,
  unique (brand_id, locale)
);

create table if not exists product_translations (
  id bigserial primary key,
  product_id bigint not null references products(id) on delete cascade,
  locale text not null,
  name text,
  description text,
  unique (product_id, locale)
);
