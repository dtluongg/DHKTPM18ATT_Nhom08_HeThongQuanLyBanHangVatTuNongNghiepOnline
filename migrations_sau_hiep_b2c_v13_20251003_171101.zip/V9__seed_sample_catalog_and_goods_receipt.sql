
-- V9: Sample categories/products/units, one supplier, and a Goods Receipt

insert into categories(name, slug, description) values
  ('Phân bón', 'phan-bon', 'Các loại phân bón vô cơ và hữu cơ'),
  ('Thuốc BVTV', 'thuoc-bvtv', 'Thuốc bảo vệ thực vật: trừ sâu, bệnh, cỏ dại');

insert into brands(name, slug, country) values
  ('Phú Mỹ', 'phu-my', 'VN'),
  ('Bayer', 'bayer', 'DE'),
  ('Syngenta', 'syngenta', 'CH');

insert into products(category_id, brand_id, name, slug, description, image_url)
select (select id from categories where slug='phan-bon'),
       (select id from brands where slug='phu-my'),
       'NPK 16-16-8 Phú Mỹ','npk-16-16-8-phu-my','Phân bón NPK 16-16-8 phù hợp nhiều loại cây trồng',null;

insert into products(category_id, brand_id, name, slug, description, image_url)
select (select id from categories where slug='phan-bon'),
       (select id from brands where slug='phu-my'),
       'Đạm Ure Phú Mỹ','ure-phu-my','Đạm Ure hạt đục, hàm lượng đạm cao',null;

insert into products(category_id, brand_id, name, slug, description, image_url)
select (select id from categories where slug='thuoc-bvtv'),
       (select id from brands where slug='bayer'),
       'Karate 2.5EC','karate-2-5ec','Thuốc trừ sâu phổ rộng',null;

insert into products(category_id, brand_id, name, slug, description, image_url)
select (select id from categories where slug='thuoc-bvtv'),
       (select id from brands where slug='syngenta'),
       'Ridomil Gold 68WG','ridomil-gold-68wg','Trị bệnh do nấm Phytophthora, Pythium',null;

insert into product_units(product_id, unit, size_label, net_qty, uom, price, sku, barcode, stock, is_active)
select (select id from products where slug='npk-16-16-8-phu-my'),'bag','25kg',25,'kg', 450000,'NPK-16168-25KG','893PM-NPK-25',0,true;
insert into product_units(product_id, unit, size_label, net_qty, uom, price, sku, barcode, stock, is_active)
select (select id from products where slug='ure-phu-my'),'bag','50kg',50,'kg', 520000,'URE-PM-50KG','893PM-URE-50',0,true;
insert into product_units(product_id, unit, size_label, net_qty, uom, price, sku, barcode, stock, is_active)
select (select id from products where slug='karate-2-5ec'),'bottle','100ml',100,'ml', 65000,'KARATE-100ML','BAYER-KRT-100',0,true;
insert into product_units(product_id, unit, size_label, net_qty, uom, price, sku, barcode, stock, is_active)
select (select id from products where slug='ridomil-gold-68wg'),'pack','100g',100,'g', 55000,'RIDOMIL-100G','SYN-RDM-100',0,true;

-- Supplier & a Goods Receipt into Main warehouse
with s as (
  insert into profiles(email, name, phone, address, role)
  values ('ncc.anphu@example.com','Công ty TNHH Vật Tư NN An Phú','0909000111','TP. Hồ Chí Minh','supplier')
  returning id
),
wh as (select id from warehouses where name='Main' limit 1)
insert into goods_receipts(supplier_id, warehouse_id, note)
select s.id, wh.id, 'Seed nhập kho đợt 1' from s, wh;

with r as (select id from goods_receipts order by id desc limit 1)
insert into goods_receipt_items(receipt_id, product_unit_id, quantity) values
  ((select id from r), (select id from product_units where sku='NPK-16168-25KG'), 200),
  ((select id from r), (select id from product_units where sku='URE-PM-50KG'), 120),
  ((select id from r), (select id from product_units where sku='KARATE-100ML'), 150),
  ((select id from r), (select id from product_units where sku='RIDOMIL-100G'), 180);
